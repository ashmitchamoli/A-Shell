#ifndef __DISCOVER_H
#define __DISCOVER_H

void A_Shell_discover(char* dir, char* target, int flags);

#endif