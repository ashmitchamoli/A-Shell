#ifndef __PROMPT_H
#define __PROMPT_H

void prompt();

#endif