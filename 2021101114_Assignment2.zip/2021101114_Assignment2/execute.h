#ifndef __EXECUTE_H
#define __EXECUTE_H

void execute_cmd(char* command);

#endif