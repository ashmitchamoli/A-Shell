#ifndef __BG_HAND_H
#define __BG_HAND_H

void bg_handler();

#endif