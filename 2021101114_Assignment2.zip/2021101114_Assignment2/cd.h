#ifndef __CD_H
#define __CD_H

void A_Shell_cd(char* arg);

#endif