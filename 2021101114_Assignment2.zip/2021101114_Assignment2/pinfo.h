#ifndef __PINFO_H
#define __PINFO_H

void A_Shell_pinfo(int pid);

#endif