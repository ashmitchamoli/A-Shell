#ifndef __LS_H
#define __LS_H

void A_Shell_ls(char** dirs, int num_dir, int flags);

#endif