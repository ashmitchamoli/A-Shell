#ifndef __INIT_SHELL_H
#define __INIT_SHELL_H

void init_shell();

#endif